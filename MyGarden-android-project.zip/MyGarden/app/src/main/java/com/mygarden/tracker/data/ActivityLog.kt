package com.mygarden.tracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class LogType { WATER, FERTILIZE }

@Entity(tableName = "activity_logs")
data class ActivityLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val type: LogType,
    val timestamp: Long,
    val note: String? = null
)
