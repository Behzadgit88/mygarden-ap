package com.mygarden.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mygarden.tracker.data.Product
import com.mygarden.tracker.data.ProductType
import com.mygarden.tracker.ui.theme.Amber
import com.mygarden.tracker.ui.theme.AmberBg
import com.mygarden.tracker.ui.theme.Cream2
import com.mygarden.tracker.ui.theme.Leaf
import com.mygarden.tracker.ui.theme.LeafDark
import com.mygarden.tracker.ui.theme.MyGardenTheme
import com.mygarden.tracker.ui.theme.Soil
import com.mygarden.tracker.ui.theme.SoilLight
import com.mygarden.tracker.ui.theme.Water
import com.mygarden.tracker.ui.theme.WaterBg
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val viewModel: GardenViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyGardenTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    GardenScreen(viewModel)
                }
            }
        }
    }
}

// تعداد روزهایی که از یک زمان مشخص گذشته، یا null اگر هنوز ثبت نشده
fun daysSince(timestamp: Long?): Long? {
    if (timestamp == null) return null
    val diff = System.currentTimeMillis() - timestamp
    return TimeUnit.MILLISECONDS.toDays(diff)
}

fun daysLabel(days: Long?): String {
    return when (days) {
        null -> "ثبت نشده"
        0L -> "امروز"
        1L -> "دیروز"
        else -> "$days روز پیش"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GardenScreen(viewModel: GardenViewModel) {
    val products by viewModel.products.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var fertilizeTarget by remember { mutableStateOf<Product?>(null) }

    Scaffold(
        containerColor = Cream2,
        topBar = {
            TopAppBar(
                title = { Text("🌿 باغچه من", fontWeight = FontWeight.Bold, color = LeafDark) },
                actions = {
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(Icons.Filled.Add, contentDescription = "افزودن محصول", tint = Leaf)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Cream2)
            )
        }
    ) { padding ->
        if (products.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🌱", fontSize = 40.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("هنوز محصولی اضافه نکرده‌ای", color = SoilLight)
                    Text("با دکمه + شروع کن", color = SoilLight, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(products, key = { it.id }) { product ->
                    ProductCard(
                        product = product,
                        onWater = { viewModel.markWatered(product) },
                        onFertilizeClick = { fertilizeTarget = product },
                        onDelete = { viewModel.deleteProduct(product) }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        AddProductDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, type ->
                viewModel.addProduct(name, type)
                showAddDialog = false
            }
        )
    }

    fertilizeTarget?.let { product ->
        FertilizeDialog(
            product = product,
            onDismiss = { fertilizeTarget = null },
            onConfirm = { fertilizerName ->
                viewModel.markFertilized(product, fertilizerName)
                fertilizeTarget = null
            }
        )
    }
}

@Composable
fun ProductCard(
    product: Product,
    onWater: () -> Unit,
    onFertilizeClick: () -> Unit,
    onDelete: () -> Unit
) {
    val waterDays = daysSince(product.lastWatered)
    val fertDays = daysSince(product.lastFertilized)
    val waterWarn = waterDays == null || waterDays >= 4
    var showMenu by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(
                            if (product.type == ProductType.TREE) Color(0xFFE4EEE0) else Color(0xFFFBEFD9),
                            RoundedCornerShape(12.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (product.type == ProductType.TREE) "🌳" else "🥬", fontSize = 20.sp)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(product.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        if (product.type == ProductType.TREE) "درخت" else "سبزیجات",
                        fontSize = 11.sp, color = SoilLight
                    )
                }
                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Text("⋮", fontSize = 18.sp, color = SoilLight)
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(text = { Text("حذف محصول") }, onClick = {
                            showMenu = false
                            onDelete()
                        })
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            InfoRow(
                emoji = "💧",
                label = "آخرین آبیاری",
                valueText = daysLabel(waterDays),
                background = if (waterWarn) AmberBg else WaterBg,
                pillColor = if (waterWarn) Amber else Water,
                buttonText = "آب داده شد",
                buttonColor = Leaf,
                onClick = onWater
            )

            Spacer(Modifier.height(8.dp))

            InfoRow(
                emoji = "🌱",
                label = "آخرین کوددهی",
                valueText = daysLabel(fertDays),
                background = Cream2,
                pillColor = SoilLight,
                buttonText = "کود داده شد",
                buttonColor = Amber,
                onClick = onFertilizeClick
            )

            product.lastFertilizerName?.let {
                Spacer(Modifier.height(6.dp))
                Text("نوع کود آخر: $it", fontSize = 10.sp, color = SoilLight)
            }
        }
    }
}

@Composable
fun InfoRow(
    emoji: String,
    label: String,
    valueText: String,
    background: Color,
    pillColor: Color,
    buttonText: String,
    buttonColor: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(background, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 13.sp)
            Spacer(Modifier.width(6.dp))
            Text(label, fontSize = 12.sp, color = Soil)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .background(pillColor, RoundedCornerShape(999.dp))
                    .padding(horizontal = 9.dp, vertical = 3.dp)
            ) {
                Text(valueText, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text(buttonText, fontSize = 10.sp, color = Color.White)
            }
        }
    }
}

@Composable
fun AddProductDialog(onDismiss: () -> Unit, onConfirm: (String, ProductType) -> Unit) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(ProductType.TREE) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن محصول جدید") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم محصول") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Text("نوع محصول", fontSize = 12.sp, color = SoilLight)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = type == ProductType.TREE, onClick = { type = ProductType.TREE })
                    Text("🌳 درخت")
                    Spacer(Modifier.width(16.dp))
                    RadioButton(selected = type == ProductType.VEGETABLE, onClick = { type = ProductType.VEGETABLE })
                    Text("🥬 سبزیجات")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onConfirm(name.trim(), type) }) {
                Text("افزودن")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
fun FertilizeDialog(product: Product, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var fertilizerName by remember { mutableStateOf(product.lastFertilizerName ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت کوددهی برای ${product.name}") },
        text = {
            OutlinedTextField(
                value = fertilizerName,
                onValueChange = { fertilizerName = it },
                label = { Text("نوع کود (اختیاری)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(fertilizerName) }) { Text("ثبت شد") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}
