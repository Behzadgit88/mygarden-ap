package com.mygarden.tracker

import android.Manifest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mygarden.tracker.data.ActivityLog
import com.mygarden.tracker.data.LogType
import com.mygarden.tracker.data.Product
import com.mygarden.tracker.data.ProductType
import com.mygarden.tracker.notifications.NotificationScheduler
import com.mygarden.tracker.ui.theme.AccentGlow
import com.mygarden.tracker.ui.theme.Amber
import com.mygarden.tracker.ui.theme.AmberBg
import com.mygarden.tracker.ui.theme.Cream
import com.mygarden.tracker.ui.theme.Cream2
import com.mygarden.tracker.ui.theme.Leaf
import com.mygarden.tracker.ui.theme.LeafDark
import com.mygarden.tracker.ui.theme.MetalHighlight
import com.mygarden.tracker.ui.theme.MetalShadow
import com.mygarden.tracker.ui.theme.MyGardenTheme
import com.mygarden.tracker.ui.theme.Soil
import com.mygarden.tracker.ui.theme.SoilLight
import com.mygarden.tracker.ui.theme.Water
import com.mygarden.tracker.ui.theme.WaterBg
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val viewModel: GardenViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationScheduler.scheduleDailyReminder(this)
        setContent {
            MyGardenTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    GardenScreen(viewModel)
                }
            }
        }
    }
}

// تعداد روزهایی که از یک زمان مشخص گذشته، یا null اگر هنوز ثبت نشده
fun daysSince(timestamp: Long?): Long? {
    if (timestamp == null) return null
    val diff = System.currentTimeMillis() - timestamp
    return TimeUnit.MILLISECONDS.toDays(diff)
}

fun daysLabel(days: Long?): String {
    return when (days) {
        null -> "ثبت نشده"
        0L -> "امروز"
        1L -> "دیروز"
        else -> "$days روز پیش"
    }
}

// تعیین می‌کنه چند روز تا آبیاری بعدی مونده، بر اساس آخرین آبیاری (یا تاریخ کاشت اگه هنوز آب داده نشده)
fun nextWateringLabel(product: Product): String {
    val baseTimestamp = product.lastWatered ?: product.plantingDate ?: return "بعد از اولین آبیاری محاسبه می‌شه"
    val daysSinceBase = daysSince(baseTimestamp) ?: return "بعد از اولین آبیاری محاسبه می‌شه"
    val remaining = product.wateringIntervalDays - daysSinceBase
    return when {
        remaining > 0 -> "$remaining روز دیگه"
        remaining == 0L -> "امروز"
        else -> "دیرکرد ${-remaining} روزه"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GardenScreen(viewModel: GardenViewModel) {
    val products by viewModel.products.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var fertilizeTarget by remember { mutableStateOf<Product?>(null) }
    var historyTarget by remember { mutableStateOf<Product?>(null) }
    var showSettingsMenu by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* نتیجه‌ی درخواست مجوز اعلان */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.let { stream ->
                viewModel.exportBackup(stream) { }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            context.contentResolver.openInputStream(it)?.let { stream ->
                viewModel.importBackup(stream) { }
            }
        }
    }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("🌿 باغچه من", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = LeafDark)
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "امکانات بیشتر به‌زودی اینجا اضافه می‌شه",
                        fontSize = 12.sp,
                        color = SoilLight
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = Cream2,
            topBar = {
                TopAppBar(
                    title = { Text("🌿 باغچه من", fontWeight = FontWeight.Bold, color = LeafDark) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "منو", tint = Leaf)
                        }
                    },
                    actions = {
                        Box {
                            IconButton(onClick = { showSettingsMenu = true }) {
                                Icon(Icons.Filled.Settings, contentDescription = "تنظیمات", tint = Leaf)
                            }
                            DropdownMenu(expanded = showSettingsMenu, onDismissRequest = { showSettingsMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("تهیه نسخه پشتیبان") },
                                    onClick = {
                                        showSettingsMenu = false
                                        exportLauncher.launch("mygarden-backup.json")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("بازیابی از پشتیبان") },
                                    onClick = {
                                        showSettingsMenu = false
                                        importLauncher.launch(arrayOf("application/json"))
                                    }
                                )
                            }
                        }
                        IconButton(onClick = { showAddDialog = true }) {
                            Icon(Icons.Filled.Add, contentDescription = "افزودن محصول", tint = Leaf)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Cream2)
                )
            }
        ) { padding ->
        if (products.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🌱", fontSize = 40.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("هنوز محصولی اضافه نکرده‌ای", color = SoilLight)
                    Text("با دکمه + شروع کن", color = SoilLight, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(products, key = { it.id }) { product ->
                    ProductCard(
                        product = product,
                        onWater = { viewModel.markWatered(product) },
                        onFertilizeClick = { fertilizeTarget = product },
                        onHistoryClick = { historyTarget = product },
                        onDelete = { viewModel.deleteProduct(product) }
                    )
                }
            }
        }
    }
    }

    if (showAddDialog) {
        AddProductDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, type, plantingDaysAgo, wateringIntervalDays ->
                viewModel.addProduct(name, type, plantingDaysAgo, wateringIntervalDays)
                showAddDialog = false
            }
        )
    }

    fertilizeTarget?.let { product ->
        FertilizeDialog(
            product = product,
            onDismiss = { fertilizeTarget = null },
            onConfirm = { fertilizerName ->
                viewModel.markFertilized(product, fertilizerName)
                fertilizeTarget = null
            }
        )
    }

    historyTarget?.let { product ->
        HistoryDialog(
            product = product,
            viewModel = viewModel,
            onDismiss = { historyTarget = null }
        )
    }
}

@Composable
fun ProductCard(
    product: Product,
    onWater: () -> Unit,
    onFertilizeClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onDelete: () -> Unit
) {
    val waterDays = daysSince(product.lastWatered)
    val fertDays = daysSince(product.lastFertilized)
    val waterWarn = waterDays == null || waterDays >= 4
    val nextWateringText = nextWateringLabel(product)
    var showMenu by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }

    val cardShape = RoundedCornerShape(18.dp)
    val gradient = Brush.linearGradient(listOf(MetalHighlight, Cream, MetalShadow))

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(cardShape)
            .background(gradient)
            .border(1.dp, AccentGlow.copy(alpha = 0.15f), cardShape)
            .clickable { expanded = !expanded }
            .padding(12.dp)
    ) {
        // ---- هدر جمع‌وجور (همیشه دیده می‌شه) ----
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        if (product.type == ProductType.TREE) Color(0xFF16324A) else Color(0xFF1E3A2E),
                        RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(if (product.type == ProductType.TREE) "🌳" else "🥬", fontSize = 16.sp)
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(product.name, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = Ink)
                Text(
                    "💧 آبیاری بعدی: $nextWateringText",
                    fontSize = 10.sp,
                    color = if (nextWateringText.contains("دیرکرد")) Amber else SoilLight
                )
            }
            IconButton(onClick = { expanded = !expanded }, modifier = Modifier.size(28.dp)) {
                Text(if (expanded) "▴" else "▾", fontSize = 14.sp, color = AccentGlow)
            }
            Box {
                IconButton(onClick = { showMenu = true }, modifier = Modifier.size(28.dp)) {
                    Text("⋮", fontSize = 16.sp, color = SoilLight)
                }
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    DropdownMenuItem(text = { Text("مشاهده تاریخچه") }, onClick = {
                        showMenu = false
                        onHistoryClick()
                    })
                    DropdownMenuItem(text = { Text("حذف محصول") }, onClick = {
                        showMenu = false
                        onDelete()
                    })
                }
            }
        }

        // ---- جزئیات (فقط وقتی باز باشه دیده می‌شه) ----
        AnimatedVisibility(visible = expanded) {
            Column(Modifier.padding(top = 10.dp)) {
                if (product.type == ProductType.VEGETABLE && product.plantingDate != null) {
                    GrowthTimeline(product = product)
                    Spacer(Modifier.height(10.dp))
                }

                InfoRow(
                    emoji = "💧",
                    label = "آخرین آبیاری",
                    valueText = daysLabel(waterDays),
                    background = if (waterWarn) AmberBg else WaterBg,
                    pillColor = if (waterWarn) Amber else Water,
                    buttonText = "آب داده شد",
                    buttonColor = Leaf,
                    onClick = onWater
                )

                Spacer(Modifier.height(8.dp))

                InfoRow(
                    emoji = "🌱",
                    label = "آخرین کوددهی",
                    valueText = daysLabel(fertDays),
                    background = Color(0xFF16233A),
                    pillColor = SoilLight,
                    buttonText = "کود داده شد",
                    buttonColor = Amber,
                    onClick = onFertilizeClick
                )

                product.lastFertilizerName?.let {
                    Spacer(Modifier.height(6.dp))
                    Text("نوع کود آخر: $it", fontSize = 10.sp, color = SoilLight)
                }
            }
        }
    }
}

// وضعیت متنی هر مرحله بر اساس تعداد روزهایی که از کاشت گذشته و بازه‌ی مورد انتظار اون مرحله
fun stageStatusText(daysSincePlanting: Long, minDay: Int, maxDay: Int): String {
    return when {
        daysSincePlanting < minDay -> {
            val remainingMin = minDay - daysSincePlanting
            val remainingMax = maxDay - daysSincePlanting
            "$remainingMin تا $remainingMax روز دیگه"
        }
        daysSincePlanting <= maxDay -> "این روزهاست"
        else -> "${daysSincePlanting - maxDay} روز از این مرحله گذشته"
    }
}

fun isStageCurrent(daysSincePlanting: Long, minDay: Int, maxDay: Int): Boolean {
    return daysSincePlanting in minDay.toLong()..maxDay.toLong()
}

fun isStagePassed(daysSincePlanting: Long, maxDay: Int): Boolean {
    return daysSincePlanting > maxDay
}

@Composable
fun GrowthTimeline(product: Product) {
    val daysSincePlanting = daysSince(product.plantingDate) ?: return
    val crop = com.mygarden.tracker.data.CropCatalog.find(product.name)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF16233A), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Text(
            "🌱 کاشته شده — ${daysLabel(daysSincePlanting)}",
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            color = LeafDark
        )
        Spacer(Modifier.height(8.dp))

        MilestoneRow(
            emoji = "🌾",
            label = "سبز شدن",
            statusText = stageStatusText(daysSincePlanting, crop.germinationMin, crop.germinationMax),
            isCurrent = isStageCurrent(daysSincePlanting, crop.germinationMin, crop.germinationMax),
            isPassed = isStagePassed(daysSincePlanting, crop.germinationMax)
        )
        Spacer(Modifier.height(6.dp))
        MilestoneRow(
            emoji = "🌸",
            label = "گلدهی",
            statusText = stageStatusText(daysSincePlanting, crop.floweringMin, crop.floweringMax),
            isCurrent = isStageCurrent(daysSincePlanting, crop.floweringMin, crop.floweringMax),
            isPassed = isStagePassed(daysSincePlanting, crop.floweringMax)
        )
        Spacer(Modifier.height(6.dp))
        MilestoneRow(
            emoji = "🧺",
            label = "برداشت",
            statusText = stageStatusText(daysSincePlanting, crop.harvestMin, crop.harvestMax),
            isCurrent = isStageCurrent(daysSincePlanting, crop.harvestMin, crop.harvestMax),
            isPassed = false
        )
    }
}

@Composable
fun MilestoneRow(
    emoji: String,
    label: String,
    statusText: String,
    isCurrent: Boolean,
    isPassed: Boolean
) {
    val textColor = when {
        isCurrent -> Leaf
        isPassed -> SoilLight
        else -> Soil
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (isPassed) "✅" else emoji, fontSize = 12.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                label,
                fontSize = 11.5.sp,
                color = textColor,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
            )
        }
        Text(statusText, fontSize = 10.5.sp, color = textColor)
    }
}

@Composable
fun InfoRow(
    emoji: String,
    label: String,
    valueText: String,
    background: Color,
    pillColor: Color,
    buttonText: String,
    buttonColor: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(background, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 13.sp)
            Spacer(Modifier.width(6.dp))
            Text(label, fontSize = 12.sp, color = Soil)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .background(pillColor, RoundedCornerShape(999.dp))
                    .padding(horizontal = 9.dp, vertical = 3.dp)
            ) {
                Text(valueText, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text(buttonText, fontSize = 10.sp, color = Color.White)
            }
        }
    }
}

private val cropSuggestions = listOf(
    "خیار", "گوجه فرنگی", "لوبیا", "فلفل دلمه", "بادمجان",
    "کاهو", "تربچه", "هویج", "اسفناج", "نخود فرنگی", "ذرت", "کدو"
)

@Composable
fun AddProductDialog(onDismiss: () -> Unit, onConfirm: (String, ProductType, Int?, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(ProductType.TREE) }
    var plantingDaysAgoText by remember { mutableStateOf("") }
    var wateringIntervalText by remember { mutableStateOf("3") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن محصول جدید") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم محصول") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Text("نوع محصول", fontSize = 12.sp, color = SoilLight)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = type == ProductType.TREE, onClick = {
                        type = ProductType.TREE
                        wateringIntervalText = "5"
                    })
                    Text("🌳 درخت")
                    Spacer(Modifier.width(16.dp))
                    RadioButton(selected = type == ProductType.VEGETABLE, onClick = {
                        type = ProductType.VEGETABLE
                        wateringIntervalText = "3"
                    })
                    Text("🥬 سبزیجات")
                }

                if (type == ProductType.VEGETABLE) {
                    Spacer(Modifier.height(14.dp))
                    Text("پیشنهاد اسم رایج:", fontSize = 11.sp, color = SoilLight)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(cropSuggestions) { suggestion ->
                            SuggestionChip(
                                onClick = { name = suggestion },
                                label = { Text(suggestion, fontSize = 10.sp) }
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Text("چند روز پیش کاشتی؟ (خالی بذاری یعنی امروز)", fontSize = 11.sp, color = SoilLight)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = plantingDaysAgoText,
                        onValueChange = { new -> if (new.all { it.isDigit() }) plantingDaysAgoText = new },
                        placeholder = { Text("مثلاً 3") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(Modifier.height(14.dp))
                Text("هر چند روز آب بدی؟", fontSize = 11.sp, color = SoilLight)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = wateringIntervalText,
                    onValueChange = { new -> if (new.all { it.isDigit() }) wateringIntervalText = new },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank()) {
                    val daysAgo = if (type == ProductType.VEGETABLE) plantingDaysAgoText.toIntOrNull() ?: 0 else null
                    val interval = wateringIntervalText.toIntOrNull()?.coerceAtLeast(1) ?: 3
                    onConfirm(name.trim(), type, daysAgo, interval)
                }
            }) {
                Text("افزودن")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
fun FertilizeDialog(product: Product, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var fertilizerName by remember { mutableStateOf(product.lastFertilizerName ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت کوددهی برای ${product.name}") },
        text = {
            OutlinedTextField(
                value = fertilizerName,
                onValueChange = { fertilizerName = it },
                label = { Text("نوع کود (اختیاری)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(fertilizerName) }) { Text("ثبت شد") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
fun HistoryDialog(product: Product, viewModel: GardenViewModel, onDismiss: () -> Unit) {
    val logs by viewModel.logsForProduct(product.id).collectAsState(initial = emptyList())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تاریخچه‌ی ${product.name}") },
        text = {
            if (logs.isEmpty()) {
                Text("هنوز هیچ ثبتی برای این محصول نداری.", color = SoilLight, fontSize = 12.sp)
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(logs, key = { it.id }) { log ->
                        HistoryRow(log = log)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("بستن") }
        }
    )
}

@Composable
fun HistoryRow(log: ActivityLog) {
    val emoji = if (log.type == LogType.WATER) "💧" else "🌱"
    val label = if (log.type == LogType.WATER) "آبیاری" else "کوددهی"
    val daysAgo = daysSince(log.timestamp)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF16233A), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 13.sp)
            Spacer(Modifier.width(6.dp))
            Column {
                Text(label, fontSize = 12.sp, color = Soil, fontWeight = FontWeight.Bold)
                log.note?.let {
                    Text(it, fontSize = 10.sp, color = SoilLight)
                }
            }
        }
        Text(daysLabel(daysAgo), fontSize = 11.sp, color = SoilLight)
    }
}
