package com.mygarden.tracker.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityLogDao {
    @Query("SELECT * FROM activity_logs WHERE productId = :productId ORDER BY timestamp DESC")
    fun getForProduct(productId: Long): Flow<List<ActivityLog>>

    @Query("SELECT * FROM activity_logs")
    suspend fun getAllOnce(): List<ActivityLog>

    @Insert
    suspend fun insert(log: ActivityLog)

    @Insert
    suspend fun insertAll(logs: List<ActivityLog>)

    @Query("DELETE FROM activity_logs")
    suspend fun deleteAll()
}
