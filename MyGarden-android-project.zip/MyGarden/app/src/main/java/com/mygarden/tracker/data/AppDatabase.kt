package com.mygarden.tracker.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class Converters {
    @TypeConverter
    fun fromType(type: ProductType): String = type.name

    @TypeConverter
    fun toType(value: String): ProductType = ProductType.valueOf(value)

    @TypeConverter
    fun fromLogType(type: LogType): String = type.name

    @TypeConverter
    fun toLogType(value: String): LogType = LogType.valueOf(value)
}

@Database(entities = [Product::class, ActivityLog::class], version = 4, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun activityLogDao(): ActivityLogDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mygarden.db"
                )
                    // چون ستون جدید (plantingDate) اضافه شده، دیتابیس قدیمی رو پاک و از نو می‌سازه
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
