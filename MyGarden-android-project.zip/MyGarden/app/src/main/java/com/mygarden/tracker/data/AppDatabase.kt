package com.mygarden.tracker.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

class Converters {
    @TypeConverter
    fun fromType(type: ProductType): String = type.name

    @TypeConverter
    fun toType(value: String): ProductType = ProductType.valueOf(value)

    @TypeConverter
    fun fromLogType(type: LogType): String = type.name

    @TypeConverter
    fun toLogType(value: String): LogType = LogType.valueOf(value)
}

// این میگریشن‌ها باعث می‌شن با هر آپدیت، اطلاعات قبلی (محصولات و تاریخچه) دست‌نخورده بمونه
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE products ADD COLUMN plantingDate INTEGER")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE products ADD COLUMN wateringIntervalDays INTEGER NOT NULL DEFAULT 3")
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS activity_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                productId INTEGER NOT NULL,
                type TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                note TEXT
            )
            """.trimIndent()
        )
    }
}

@Database(entities = [Product::class, ActivityLog::class], version = 4, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun activityLogDao(): ActivityLogDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mygarden.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    // فقط اگه یه نسخه‌ی خیلی قدیمی‌تر از این‌ها باشه که مسیر میگریشن نداره، به‌عنوان آخرین راه‌حل استفاده می‌شه
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
