package com.mygarden.tracker.ui.theme

import androidx.compose.ui.graphics.Color

val Soil = Color(0xFF5B4636)
val SoilLight = Color(0xFF8A6D52)
val Leaf = Color(0xFF3D6B4A)
val LeafDark = Color(0xFF2C4E36)
val Sage = Color(0xFFA9C1A0)
val Cream = Color(0xFFF4EFE3)
val Cream2 = Color(0xFFEAE2CF)
val Amber = Color(0xFFC8863A)
val AmberBg = Color(0xFFFBEEDD)
val Water = Color(0xFF4C7A94)
val WaterBg = Color(0xFFE4F0F5)
val Ink = Color(0xFF2B2620)
