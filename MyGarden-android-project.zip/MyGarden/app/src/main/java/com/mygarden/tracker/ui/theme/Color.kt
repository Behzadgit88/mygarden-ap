package com.mygarden.tracker.ui.theme

import androidx.compose.ui.graphics.Color

// تم آبی متالیک — همون اسم متغیرها نگه داشته شده، فقط رنگ‌ها عوض شدن
val Soil = Color(0xFFE8F1FA)          // متن اصلی (روشن، روی پس‌زمینه‌ی تیره)
val SoilLight = Color(0xFF93ACC7)     // متن کم‌رنگ‌تر/ثانویه
val Leaf = Color(0xFF2D9CDB)          // آبی روشن براق (دکمه‌ها، آیکون‌ها)
val LeafDark = Color(0xFF57C4EE)      // آبی درخشان‌تر برای عنوان‌ها
val Sage = Color(0xFF6E93B7)
val Cream = Color(0xFF1B2E47)         // سطح کارت (تیره، فلزی)
val Cream2 = Color(0xFF0E1B2B)        // پس‌زمینه‌ی کل صفحه (نیوی تیره)
val Amber = Color(0xFFE0A458)
val AmberBg = Color(0xFF3A2E1E)
val Water = Color(0xFF29B6D8)
val WaterBg = Color(0xFF12283B)
val Ink = Color(0xFFE8F1FA)

// رنگ‌های اضافه برای جلوه‌ی متالیک/گرادیان
val MetalHighlight = Color(0xFF2E4A6B)   // نقطه‌ی روشن گرادیان (بالا-چپ کارت)
val MetalShadow = Color(0xFF101D2E)      // نقطه‌ی تیره گرادیان (پایین-راست کارت)
val AccentGlow = Color(0xFF3ED1FF)       // درخشش دکمه‌ی اصلی
