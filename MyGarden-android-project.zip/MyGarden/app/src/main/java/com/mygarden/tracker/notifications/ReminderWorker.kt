package com.mygarden.tracker.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.mygarden.tracker.data.AppDatabase
import com.mygarden.tracker.data.effectiveWateringInterval
import com.mygarden.tracker.weather.LocationHelper
import com.mygarden.tracker.weather.WeatherHelper
import java.util.concurrent.TimeUnit

const val REMINDER_CHANNEL_ID = "garden_reminders"
private const val NOTIFICATION_ID = 1001

class ReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val dao = AppDatabase.getInstance(applicationContext).productDao()
        val products = dao.getAllOnce()
        val now = System.currentTimeMillis()

        // اگه اخیراً بارون اومده باشه، امروز یادآوری آبیاری لازم نیست
        val location = LocationHelper.getLastKnownLocation(applicationContext)
        val recentlyRained = location?.let { (lat, lon) ->
            WeatherHelper.fetchRecentRain(lat, lon)?.recentlyRained
        } ?: false

        if (recentlyRained) return Result.success()

        val needsWatering = products.filter { product ->
            val base = product.lastWatered ?: product.plantingDate ?: return@filter false
            val daysSince = TimeUnit.MILLISECONDS.toDays(now - base)
            daysSince >= effectiveWateringInterval(product)
        }

        if (needsWatering.isEmpty()) return Result.success()

        val names = needsWatering.take(4).joinToString("، ") { it.name }
        val extra = if (needsWatering.size > 4) " و ${needsWatering.size - 4} مورد دیگه" else ""
        val message = "💧 امروز باید آب بدی: $names$extra"

        showNotification(applicationContext, message)
        return Result.success()
    }

    private fun showNotification(context: Context, message: String) {
        createChannel(context)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ActivityCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val notification = NotificationCompat.Builder(context, REMINDER_CHANNEL_ID)
            .setContentTitle("🌿 باغچه من")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                REMINDER_CHANNEL_ID,
                "یادآور آبیاری",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "یادآوری روزانه‌ی آبیاری و کوددهی محصولات"
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
