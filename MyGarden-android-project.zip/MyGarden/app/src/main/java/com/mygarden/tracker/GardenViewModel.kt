package com.mygarden.tracker

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mygarden.tracker.data.ActivityLog
import com.mygarden.tracker.data.AppDatabase
import com.mygarden.tracker.data.LogType
import com.mygarden.tracker.data.Product
import com.mygarden.tracker.data.ProductType
import com.mygarden.tracker.data.SoilType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream

class GardenViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val dao = db.productDao()
    private val logDao = db.activityLogDao()

    val products: StateFlow<List<Product>> = dao.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addProduct(
        name: String,
        type: ProductType,
        plantingDaysAgo: Int?,
        wateringIntervalDays: Int,
        soilType: SoilType
    ) {
        viewModelScope.launch {
            val plantingDate = plantingDaysAgo?.let {
                System.currentTimeMillis() - (it.toLong() * 24 * 60 * 60 * 1000)
            }
            dao.insert(
                Product(
                    name = name,
                    type = type,
                    plantingDate = plantingDate,
                    wateringIntervalDays = wateringIntervalDays,
                    soilType = soilType
                )
            )
        }
    }

    fun markWatered(product: Product) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            dao.update(product.copy(lastWatered = now))
            logDao.insert(ActivityLog(productId = product.id, type = LogType.WATER, timestamp = now))
        }
    }

    fun markFertilized(product: Product, fertilizerName: String) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val nameToSave = if (fertilizerName.isBlank()) product.lastFertilizerName else fertilizerName
            dao.update(
                product.copy(
                    lastFertilized = now,
                    lastFertilizerName = nameToSave
                )
            )
            logDao.insert(
                ActivityLog(
                    productId = product.id,
                    type = LogType.FERTILIZE,
                    timestamp = now,
                    note = nameToSave
                )
            )
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            dao.delete(product)
        }
    }

    fun logsForProduct(productId: Long): Flow<List<ActivityLog>> = logDao.getForProduct(productId)

    // ---------- پشتیبان‌گیری و بازیابی ----------

    fun exportBackup(outputStream: OutputStream, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            try {
                val products = dao.getAllOnce()
                val logs = logDao.getAllOnce()

                val productsJson = JSONArray()
                products.forEach { p ->
                    productsJson.put(
                        JSONObject().apply {
                            put("id", p.id)
                            put("name", p.name)
                            put("type", p.type.name)
                            put("lastWatered", p.lastWatered ?: JSONObject.NULL)
                            put("lastFertilized", p.lastFertilized ?: JSONObject.NULL)
                            put("lastFertilizerName", p.lastFertilizerName ?: JSONObject.NULL)
                            put("plantingDate", p.plantingDate ?: JSONObject.NULL)
                            put("wateringIntervalDays", p.wateringIntervalDays)
                            put("soilType", p.soilType.name)
                        }
                    )
                }

                val logsJson = JSONArray()
                logs.forEach { l ->
                    logsJson.put(
                        JSONObject().apply {
                            put("id", l.id)
                            put("productId", l.productId)
                            put("type", l.type.name)
                            put("timestamp", l.timestamp)
                            put("note", l.note ?: JSONObject.NULL)
                        }
                    )
                }

                val root = JSONObject().apply {
                    put("products", productsJson)
                    put("logs", logsJson)
                    put("exportedAt", System.currentTimeMillis())
                }

                outputStream.use { it.write(root.toString().toByteArray()) }
                onResult(true)
            } catch (e: Exception) {
                onResult(false)
            }
        }
    }

    fun importBackup(inputStream: InputStream, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            try {
                val text = inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(text)

                val productsJson = root.getJSONArray("products")
                val newProducts = mutableListOf<Product>()
                for (i in 0 until productsJson.length()) {
                    val o = productsJson.getJSONObject(i)
                    newProducts.add(
                        Product(
                            id = o.getLong("id"),
                            name = o.getString("name"),
                            type = ProductType.valueOf(o.getString("type")),
                            lastWatered = if (o.isNull("lastWatered")) null else o.getLong("lastWatered"),
                            lastFertilized = if (o.isNull("lastFertilized")) null else o.getLong("lastFertilized"),
                            lastFertilizerName = if (o.isNull("lastFertilizerName")) null else o.getString("lastFertilizerName"),
                            plantingDate = if (o.isNull("plantingDate")) null else o.getLong("plantingDate"),
                            wateringIntervalDays = o.optInt("wateringIntervalDays", 3),
                            soilType = if (o.has("soilType") && !o.isNull("soilType"))
                                SoilType.valueOf(o.getString("soilType")) else SoilType.LOAMY
                        )
                    )
                }

                val logsJson = root.optJSONArray("logs") ?: JSONArray()
                val newLogs = mutableListOf<ActivityLog>()
                for (i in 0 until logsJson.length()) {
                    val o = logsJson.getJSONObject(i)
                    newLogs.add(
                        ActivityLog(
                            id = o.getLong("id"),
                            productId = o.getLong("productId"),
                            type = LogType.valueOf(o.getString("type")),
                            timestamp = o.getLong("timestamp"),
                            note = if (o.isNull("note")) null else o.getString("note")
                        )
                    )
                }

                dao.deleteAll()
                logDao.deleteAll()
                if (newProducts.isNotEmpty()) dao.insertAll(newProducts)
                if (newLogs.isNotEmpty()) logDao.insertAll(newLogs)

                onResult(true)
            } catch (e: Exception) {
                onResult(false)
            }
        }
    }
}
