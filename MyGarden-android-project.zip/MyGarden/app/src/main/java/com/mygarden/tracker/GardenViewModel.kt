package com.mygarden.tracker

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mygarden.tracker.data.AppDatabase
import com.mygarden.tracker.data.Product
import com.mygarden.tracker.data.ProductType
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GardenViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getInstance(application).productDao()

    val products: StateFlow<List<Product>> = dao.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addProduct(name: String, type: ProductType, plantingDaysAgo: Int?) {
        viewModelScope.launch {
            val plantingDate = plantingDaysAgo?.let {
                System.currentTimeMillis() - (it.toLong() * 24 * 60 * 60 * 1000)
            }
            dao.insert(Product(name = name, type = type, plantingDate = plantingDate))
        }
    }

    fun markWatered(product: Product) {
        viewModelScope.launch {
            dao.update(product.copy(lastWatered = System.currentTimeMillis()))
        }
    }

    fun markFertilized(product: Product, fertilizerName: String) {
        viewModelScope.launch {
            val nameToSave = if (fertilizerName.isBlank()) product.lastFertilizerName else fertilizerName
            dao.update(
                product.copy(
                    lastFertilized = System.currentTimeMillis(),
                    lastFertilizerName = nameToSave
                )
            )
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            dao.delete(product)
        }
    }
}
