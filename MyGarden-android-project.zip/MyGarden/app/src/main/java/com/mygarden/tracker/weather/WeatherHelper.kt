package com.mygarden.tracker.weather

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class RainInfo(val yesterdayMm: Double, val todayMm: Double) {
    // اگه دیروز یا امروز بارون قابل‌توجهی اومده باشه، آبیاری فعلاً لازم نیست
    val recentlyRained: Boolean get() = yesterdayMm >= 3.0 || todayMm >= 3.0
}

object WeatherHelper {

    // سرویس رایگان Open-Meteo — بدون نیاز به کلید API
    fun fetchRecentRain(latitude: Double, longitude: Double): RainInfo? {
        return try {
            val url = "https://api.open-meteo.com/v1/forecast" +
                "?latitude=$latitude&longitude=$longitude" +
                "&daily=precipitation_sum&past_days=1&forecast_days=1&timezone=auto"

            val connection = URL(url).openConnection() as HttpURLConnection
            connection.connectTimeout = 8000
            connection.readTimeout = 8000
            connection.requestMethod = "GET"

            val responseText = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            val root = JSONObject(responseText)
            val daily = root.getJSONObject("daily")
            val precipitation = daily.getJSONArray("precipitation_sum")

            // با past_days=1 و forecast_days=1، ایندکس 0 = دیروز، ایندکس 1 = امروز
            val yesterday = if (precipitation.length() > 0) precipitation.optDouble(0, 0.0) else 0.0
            val today = if (precipitation.length() > 1) precipitation.optDouble(1, 0.0) else 0.0

            RainInfo(yesterdayMm = yesterday, todayMm = today)
        } catch (e: Exception) {
            null
        }
    }
}
