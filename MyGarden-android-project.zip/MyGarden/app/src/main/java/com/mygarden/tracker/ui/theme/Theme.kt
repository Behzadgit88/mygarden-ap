package com.mygarden.tracker.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val MetallicBlueColors = darkColorScheme(
    primary = Leaf,
    onPrimary = Cream2,
    secondary = Amber,
    background = Cream2,
    surface = Cream,
    onBackground = Ink,
    onSurface = Ink
)

@Composable
fun MyGardenTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MetallicBlueColors,
        content = content
    )
}
