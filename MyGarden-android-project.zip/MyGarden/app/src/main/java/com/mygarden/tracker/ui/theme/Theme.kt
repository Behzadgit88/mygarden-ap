package com.mygarden.tracker.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = Leaf,
    onPrimary = Cream,
    secondary = Amber,
    background = Cream2,
    surface = Cream,
    onBackground = Ink,
    onSurface = Ink
)

@Composable
fun MyGardenTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        content = content
    )
}
