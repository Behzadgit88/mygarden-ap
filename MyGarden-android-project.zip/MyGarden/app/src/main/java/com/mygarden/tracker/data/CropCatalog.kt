package com.mygarden.tracker.data

// روزهای تقریبی از زمان کاشت (بذر) — بازه‌ی min تا max برای هر مرحله
data class CropProfile(
    val germinationMin: Int,
    val germinationMax: Int,
    val floweringMin: Int,
    val floweringMax: Int,
    val harvestMin: Int,
    val harvestMax: Int
)

object CropCatalog {

    // مقدار پیش‌فرض برای هر سبزی/حبوباتی که توی لیست زیر نباشه
    val DEFAULT = CropProfile(
        germinationMin = 6, germinationMax = 12,
        floweringMin = 35, floweringMax = 50,
        harvestMin = 55, harvestMax = 75
    )

    private val catalog: Map<String, CropProfile> = mapOf(
        "خیار" to CropProfile(5, 10, 40, 55, 50, 70),
        "گوجه" to CropProfile(6, 14, 40, 50, 60, 85),
        "گوجه فرنگی" to CropProfile(6, 14, 40, 50, 60, 85),
        "لوبیا" to CropProfile(6, 10, 30, 40, 50, 60),
        "فلفل" to CropProfile(10, 21, 50, 60, 60, 90),
        "فلفل دلمه" to CropProfile(10, 21, 50, 60, 60, 90),
        "بادمجان" to CropProfile(7, 14, 50, 60, 65, 80),
        "کاهو" to CropProfile(4, 10, 35, 45, 45, 55),
        "تربچه" to CropProfile(3, 7, 15, 20, 21, 30),
        "اسفناج" to CropProfile(5, 10, 25, 35, 35, 45),
        "هویج" to CropProfile(10, 21, 45, 60, 60, 80),
        "نخود فرنگی" to CropProfile(7, 14, 30, 40, 55, 70),
        "نخود" to CropProfile(7, 14, 30, 40, 55, 70),
        "ذرت" to CropProfile(6, 10, 45, 55, 60, 100),
        "کدو" to CropProfile(5, 10, 30, 40, 45, 55),
        "کدو سبز" to CropProfile(5, 10, 30, 40, 45, 55),
        "هندوانه" to CropProfile(7, 14, 35, 45, 70, 90),
        "خربزه" to CropProfile(7, 14, 35, 45, 65, 85),
        "پیاز" to CropProfile(7, 14, 60, 80, 90, 120),
        "کلم" to CropProfile(4, 7, 45, 60, 60, 100)
    )

    // جستجوی نام محصول توی کاتالوگ (تطبیق تقریبی) و برگردوندن پروفایل مناسب
    fun find(productName: String): CropProfile {
        val normalized = productName.trim()
        catalog[normalized]?.let { return it }
        catalog.entries.firstOrNull { normalized.contains(it.key) }?.let { return it.value }
        return DEFAULT
    }

    // پیشنهاد نوع کود بر اساس مرحله‌ی رشدی که محصول توش هست
    fun fertilizerAdvice(daysSincePlanting: Long, crop: CropProfile): String {
        return when {
            daysSincePlanting < crop.germinationMin -> "فعلاً نیازی به کود نیست؛ فقط رطوبت خاک رو حفظ کن"
            daysSincePlanting < crop.floweringMin -> "کود نیتروژن‌دار (برای رشد برگ و ساقه)"
            daysSincePlanting <= crop.harvestMax -> "کود فسفر و پتاسیم بالا (برای گلدهی و میوه‌دهی)"
            else -> "کود متعادل نگهدارنده"
        }
    }
}
