package com.mygarden.tracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ProductType { TREE, VEGETABLE }

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: ProductType,
    val lastWatered: Long? = null,
    val lastFertilized: Long? = null,
    val lastFertilizerName: String? = null,
    val plantingDate: Long? = null,
    val wateringIntervalDays: Int = 3
)
