package com.mygarden.tracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ProductType { TREE, VEGETABLE }

enum class SoilType { CLAY, SANDY, LOAMY }

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: ProductType,
    val lastWatered: Long? = null,
    val lastFertilized: Long? = null,
    val lastFertilizerName: String? = null,
    val plantingDate: Long? = null,
    val wateringIntervalDays: Int = 3,
    val soilType: SoilType = SoilType.LOAMY
)

// خاک رسی دیرتر خشک می‌شه (فاصله‌ی آبیاری رو بیشتر می‌کنیم)، خاک شنی زودتر (فاصله رو کمتر می‌کنیم)
fun soilMultiplier(soilType: SoilType): Double = when (soilType) {
    SoilType.CLAY -> 1.4
    SoilType.SANDY -> 0.7
    SoilType.LOAMY -> 1.0
}

fun effectiveWateringInterval(product: Product): Int {
    val adjusted = product.wateringIntervalDays * soilMultiplier(product.soilType)
    return adjusted.toInt().coerceAtLeast(1)
}

fun soilTypeLabel(soilType: SoilType): String = when (soilType) {
    SoilType.CLAY -> "رسی"
    SoilType.SANDY -> "شنی"
    SoilType.LOAMY -> "لومی (معمولی)"
}
